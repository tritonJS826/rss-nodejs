const getAll = async () => {
  // TODO: mock implementation. should be replaced during task development
  return [];
};

module.exports = { getAll };
