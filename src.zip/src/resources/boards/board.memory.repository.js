const getAll = async () => {
  // TODO: mock implementation. should be replaced during task development
  const boards = [
    { id: 'id1', title: 'title1', columns: 'columns1' },
    { id: 'id2', title: 'title2', columns: 'columns2' },
    { id: 'id3', title: 'title3', columns: 'columns3' }
  ];
  return boards;
};

module.exports = { getAll };
