const getAll = async () => {
  // TODO: mock implementation. should be replaced during task development
  // DB is here
  return [];
};

module.exports = { getAll };
